#!/bin/bash
find -type f -iname *0310* | grep $1 
find -type f -iname *0312* | grep $1
find -type f -iname *0315* | grep $1  
